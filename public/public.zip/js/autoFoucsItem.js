const autoFoucs = (idx) => {
    document.querySelector(`.price1-${idx}`).focus();
};