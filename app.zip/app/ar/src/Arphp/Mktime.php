<?php

namespace Arphp;

include_once __DIR__ . '/../../I18N/Arabic/Mktime.php';

class Mktime extends \I18N_Arabic_Mktime {
    
}
