<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/Stemmer.php';

class Stemmer extends \I18N_Arabic_Stemmer{
    
}
