<?php

namespace Arphp;

include_once __DIR__ .'/../../I18N/Arabic/CompressStr.php';

class CompressStr extends \I18N_Arabic_CompressStr {
    
}
