<?php 
namespace Arphp ;
include_once __DIR__ .'/../../I18N/Arabic/AutoSummarize.php';
class AutoSummarize extends \I18N_Arabic_AutoSummarize
{
    
}
