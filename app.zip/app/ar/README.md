# This package is abandoned and no longer maintained. The author suggests using the khaled.alshamaa/ar-php package instead.
